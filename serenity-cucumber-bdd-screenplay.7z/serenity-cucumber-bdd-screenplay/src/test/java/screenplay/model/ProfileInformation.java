package screenplay.model;

public class ProfileInformation {
}
