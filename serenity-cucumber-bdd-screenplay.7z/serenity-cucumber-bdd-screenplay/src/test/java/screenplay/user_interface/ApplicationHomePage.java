package screenplay.user_interface;

import net.serenitybdd.core.pages.PageObject;

public class ApplicationHomePage extends PageObject {}
